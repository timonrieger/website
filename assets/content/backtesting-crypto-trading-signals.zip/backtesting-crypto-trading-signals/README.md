# Disclaimer
This script is provided for informational purposes only and should not be considered financial advice.
You should not run this code. It is just for viewing to evaluate the accuracy of the study.

# Important Note
The script lacks comprehensive error handling and may fail under certain conditions.
It is designed to work with data from a specific Telegram channel and may not be compatible with data from other sources due to the wide variety of message formats.
The format_data function must be adapted to suit the specific structure of your data input.
